# Midnight-Team-Web-Dev

The assignment expected the members of hte group to recreate a given portfolio.
This has been successfully done using html, css and bootsrap library.

#Team members
Ian Joseph : ianjosephmak@gmail.com
Rennish Mboya : rennishmboya89@gmail.com

Both team members played their part in the coding process.
consultations were done on both ends to make sure work is done seamlessly.
